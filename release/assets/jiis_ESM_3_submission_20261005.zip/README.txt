ONLINE RESOURCE 3: IDENTIFICATION AND INSTRUCTIONS

Article title: Reliability Boundaries of HyDE-Style Query Expansion in Multi-Hop Intelligent Information Retrieval
Journal: Journal of Intelligent Information Systems
Authors (in manuscript order): Shiyong Xiong; Xingyun Chen
Shared affiliation (both authors): School of Computer Science and Technology, Chongqing University of Posts and Telecommunications, Chongqing 400065, China
Corresponding author: Shiyong Xiong
Corresponding author's affiliation: School of Computer Science and Technology, Chongqing University of Posts and Telecommunications, Chongqing 400065, China
Corresponding e-mail: 1771856981@qq.com

CAPTION
Versioned serializer and new-question paired-metric reanalysis capsule.

SCOPE
This package recomputes four serializer and 27 random 300-question holdout contrasts (31 total) and checks 615 numeric fields against frozen summaries. Seven rejection tests check input integrity.
This is bounded numerical reconstruction/reanalysis. It does not rescore raw predicted answers, rerun a model, rebuild an index/corpus, or establish independent human validation. Numeric support metrics do not establish semantic sufficiency. Raw benchmark/corpus/news text, questions, gold answers, generated answers, prompts, private endpoints/credentials, model weights and indexes are excluded.

PACKAGE LAYOUT
README.txt: this journal identification and usage document.
submission_metadata.json: machine-readable identification and packaging provenance.
capsule/: the original frozen numerical package, including its manifest, software license, source code, sanitized inputs and original instructions.

REQUIREMENTS
Python 3.10 or newer and NumPy 2.2.6; install the included requirements.txt in your own environment.

HOW TO RUN
Extract this entire ZIP into a new directory. Open a terminal in the extracted directory and run:

cd capsule
python -m pip install -r requirements.txt
python -I scripts/reanalyze_jiis_followup_metrics.py --input-root data --out outputs
python -I -m unittest discover -s tests -p test_followup_metric_reanalysis.py -v

EXPECTED RESULT
Serializer4 and holdout27 paired contrasts and numeric summaries reproduced; all seven input-rejection tests pass.
Generated numerical outputs are placed in capsule/outputs/. They are outputs, not frozen source inputs. Do not edit files listed in capsule/manifest.json to make checks pass.

PROVENANCE AND PUBLICATION STATUS
Frozen numerical capsule version: 0.2.0-local-20261004
Journal packaging revision: jiis-si-metadata-20261005 (prepared 2026-10-05).
Original capsule archive SHA-256: ffac46f7be027474e05d9ba01e650e2f798939ca455f93a21d4306385857d441
Versioned public code: https://github.com/creator-perterson/hyde-multihop-rag-reproducibility/tree/a68aaaacdd5093eaaf0d094b34da5f418255317a/reproducibility/followup
The original capsule was packaged locally on 2026-10-04 and later made public in the GitHub repository. Its original files, manifests, versions and packaging-time local-only metadata remain unchanged. This submission ZIP adds only the two identification/provenance files at its root; it therefore has a different archive hash from the original public ZIP. No archival DOI has been assigned.

LICENSE AND THIRD-PARTY LIMITS
Project-authored software is covered by capsule/LICENSE (MIT). Third-party datasets, models and dependencies retain their own terms. No model or dependency distribution is bundled. The manuscript text and figures are not automatically covered by the software license.
