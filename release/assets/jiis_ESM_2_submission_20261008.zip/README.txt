ONLINE RESOURCE 2: IDENTIFICATION AND INSTRUCTIONS

Article title: Reliability Boundaries of HyDE-Style Query Expansion in Multi-Hop Intelligent Information Retrieval
Journal: Journal of Intelligent Information Systems
Authors (in manuscript order): Xingyun Chen; Shiyong Xiong
Shared affiliation (both authors): School of Computer Science and Technology, Chongqing University of Posts and Telecommunications, Chongqing 400065, China
Corresponding author: Xingyun Chen
Corresponding author's affiliation: School of Computer Science and Technology, Chongqing University of Posts and Telecommunications, Chongqing 400065, China
Corresponding e-mail: cxy201318@qq.com

CAPTION
Versioned table-reconstruction and historical paired-retrieval reanalysis capsule.

SCOPE
This package reconstructs legacy summary tables and two open-generator tables and recomputes eight historical paired retrieval contrasts from sanitized metrics.
This is bounded numerical reconstruction/reanalysis. It does not rescore raw predicted answers, rerun a model, rebuild an index/corpus, or establish independent human validation. Numeric support metrics do not establish semantic sufficiency. Raw benchmark/corpus/news text, questions, gold answers, generated answers, prompts, private endpoints/credentials, model weights and indexes are excluded.

MANUSCRIPT SCOPE AND TERMINOLOGY
The associated manuscript uses matched question-only baselines and distinguishes retrieval, delivered evidence and answers as separate validation targets. Its findings are limited to tested configurations and do not establish a universal prediction or method-selection rule.

PACKAGE LAYOUT
README.txt: this journal identification and usage document.
submission_metadata.json: machine-readable identification and packaging provenance.
capsule/: the original frozen numerical package, including its manifest, software license, source code, sanitized inputs and original instructions.

REQUIREMENTS
Python 3.10 or newer; standard library only.

HOW TO RUN
Extract this entire ZIP into a new directory. Open a terminal in the extracted directory and run:

cd capsule
python -S run.py

EXPECTED RESULT
PASS: eight paired contrasts match; two open-generator tables byte-identical; legacy table rebuilt.
Generated numerical outputs are placed in capsule/outputs/. They are outputs, not frozen source inputs. Do not edit files listed in capsule/manifest.json to make checks pass.

PROVENANCE AND PUBLICATION STATUS
Frozen numerical capsule version: 0.1.0-local-20261004
Journal packaging revision: jiis-author-order-20261008 (prepared 2026-10-08).
Original capsule archive SHA-256: 160aa6c52cc1941240fcbad254d40a6c9f8c2e3d176a7b694625abb17afe4ad4
Versioned public code: https://github.com/creator-perterson/hyde-multihop-rag-reproducibility/tree/a68aaaacdd5093eaaf0d094b34da5f418255317a/reproducibility/legacy
The original capsule was packaged locally on 2026-10-04 and later made public in the GitHub repository. Its original files, manifests, versions and packaging-time local-only metadata remain unchanged. This submission ZIP adds only the two identification/provenance files at its root; it therefore has a different archive hash from the original public ZIP. No archival DOI has been assigned.

LICENSE AND THIRD-PARTY LIMITS
Project-authored software is covered by capsule/LICENSE (MIT). Third-party datasets, models and dependencies retain their own terms. No model or dependency distribution is bundled. The manuscript text and figures are not automatically covered by the software license.
